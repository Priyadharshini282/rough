#ultrasonic sensor

import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

TRIG = 23
ECHO = 24
GPIO.setwarnings(False)

GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def measure_distance():
    GPIO.output(TRIG, GPIO.LOW)
    time.sleep(0.05)  # Short pause to settle the sensor

    # Trigger the sensor
    GPIO.output(TRIG, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG, GPIO.LOW)

    # Wait for echo to go HIGH
    timeout = time.time() + 0.04
    while GPIO.input(ECHO) == 0 and time.time() < timeout:
        pass
    if time.time() >= timeout:
        print("Timeout waiting for echo to go HIGH")
        return None

    start_pulse = time.time()

    # Wait for echo to go LOW
    timeout = time.time() + 0.04
    while GPIO.input(ECHO) == 1 and time.time() < timeout:
        pass
    if time.time() >= timeout:
        print("Timeout waiting for echo to go LOW")
        return None

    end_pulse = time.time()

    # Calculate distance
    pulse_duration = end_pulse - start_pulse
    distance = round(pulse_duration * 17150, 2)
    return distance

try:
    print("Measuring distance. Press Ctrl+C to stop.")
    while True:
        dist = measure_distance()
        if dist is not None:
            print(f"Distance: {dist} cm")
        time.sleep(1)

except KeyboardInterrupt:
    print("\nMeasurement stopped by user.")

finally:
    GPIO.cleanup()



#LED

import RPi.GPIO as GPIO
import time

# Use BCM GPIO numbering
GPIO.setmode(GPIO.BCM)
LED_PIN = 17  # GPIO17

# Set the LED pin as output
GPIO.setup(LED_PIN, GPIO.OUT)

print("Blinking LED. Press Ctrl+C to stop.")
try:
    while True:
        GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on LED
        time.sleep(1)                    # Wait 1 second
        GPIO.output(LED_PIN, GPIO.LOW)   # Turn off LED
        time.sleep(1)                    # Wait 1 second

except KeyboardInterrupt:
    print("\nExiting program.")

finally:
    GPIO.cleanup()  # Clean up GPIO on exit



#moisture

import RPi.GPIO as GPIO
import time

MOISTURE_PIN = 18  # GPIO18

GPIO.setmode(GPIO.BCM)
GPIO.setup(MOISTURE_PIN, GPIO.IN)

print("Reading moisture sensor. Press Ctrl+C to stop.")
try:
    while True:
        moisture_detected = GPIO.input(MOISTURE_PIN)

        if moisture_detected == 0:
            print("Soil is Wet 💧")
        else:
            print("Soil is Dry 🌵")

        time.sleep(2)

except KeyboardInterrupt:
    print("\nStopped by user.")

finally:
    GPIO.cleanup()



#Rain drop

from time import sleep
from gpiozero import InputDevice

no_rain = InputDevice(18)

while True:
    if not no_rain.is_active:
        print("No rain")
    else:
        print("Raining")
    time.sleep(1)

 
#buzzer



from time import sleep
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)
BUZZER_PIN = 18
gpio.setup(BUZZER_PIN,gpio.OUT) 
while True:
    gpio.output(BUZZER_PIN,gpio.HIGH)
    sleep(1)
    gpio.output(BUZZER_PIN,gpio.LOW)
    sleep(1)


