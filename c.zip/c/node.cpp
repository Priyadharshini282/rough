// ########################################################
// # TEMPERATURE SENSOR CODE
// ########################################################

float temp;
int temppin = 0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int sensorvalue = analogRead(temppin);
  float voltage = sensorvalue * (5.0 / 1023.0);
  temp = voltage / 0.1;

  Serial.print("TEMPERATURE = ");
  Serial.print(temp);
  Serial.print("oC");
  Serial.println();

  delay(1000);
}


// ########################################################
// # SOIL MOISTURE SENSOR CODE
// ########################################################

const int sensor_pin = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  float moisture_percentage;
  int sensor_analog;

  sensor_analog = analogRead(sensor_pin);
  moisture_percentage = (100 - ((sensor_analog / 1023.00) * 100));

  Serial.print("Moisture Percentage: ");
  Serial.print(moisture_percentage);
  Serial.print("% \n\n");

  delay(1000);
}


// ########################################################
// # RAIN SENSOR CODE
// ########################################################

#define POWER_PIN D7
#define AO_PIN    A0

void setup() {
  Serial.begin(9600);
  pinMode(POWER_PIN, OUTPUT);
}

void loop() {
  digitalWrite(POWER_PIN, HIGH);
  delay(10);
  
  int rainValue = analogRead(AO_PIN);
  
  digitalWrite(POWER_PIN, LOW);
  Serial.println(rainValue);
  
  delay(1000);
}


// ########################################################
// # ULTRASONIC SENSOR CODE
// ########################################################

const int trigPin = 12;
const int echoPin = 14;

#define SOUND_VELOCITY 0.034
#define CM_TO_INCH 0.393701

long duration;
float distanceCm;
float distanceInch;

void setup() {
  Serial.begin(115200);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigPin, LOW);
  duration = pulseIn(echoPin, HIGH);

  distanceCm = duration * SOUND_VELOCITY / 2;
  distanceInch = distanceCm * CM_TO_INCH;

  Serial.print("Distance (cm): ");
  Serial.println(distanceCm);

  Serial.print("Distance (inch): ");
  Serial.println(distanceInch);

  delay(1000);
}


// ########################################################
// # MOTION SENSOR CODE
// ########################################################

int sensor = 4;

void setup() {
  pinMode(sensor, INPUT);
  Serial.begin(9600);
}

void loop() {
  int state = digitalRead(sensor);

  if (state == HIGH) {
    Serial.println("Motion detected");
  } else {
    Serial.println("Motion absent");
  }

  delay(1000);
}
